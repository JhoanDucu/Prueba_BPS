function fibonacci( times = prompt('Comenzando en 1, ¿cuantos numeros mas desea imprimir? '), now = 1, after = 1, before = 0){
   let numeros = [0];
   let total = 0;
    for (times; times>0; times--) {
       before = after;
       after = now;
       numeros.push(before);
       total += before;
       now = before + after;
    }
    alert('Los numeros sin incluir 0 son: '+ numeros + ' y sumarlos es igual a '+total);
}